﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd3_IsomatovS_pr24
{
    public class HighCalorieFood : Food
    {
        public double Calories { get; set; }

        public HighCalorieFood(string name, double protein, double carbs, double calories)
            : base(name, protein, carbs)
        {
            Calories = calories;
        }

        public override double CalculateQ()
        {
            return base.CalculateQ() * 1.2 + Calories * 7;
        }

        public override string ToString()
        {
            return $"[Улучшенный] {base.ToString()}, Калории: {Calories}, Qp: {CalculateQ():F2}";
        }
    }
}
