﻿
namespace zd3_IsomatovS_pr24
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtProtein = new System.Windows.Forms.TextBox();
            this.txtCarbs = new System.Windows.Forms.TextBox();
            this.txtCalories = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnAddDerived = new System.Windows.Forms.Button();
            this.btnRemoveByName = new System.Windows.Forms.Button();
            this.txtRemoveName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.listBoxOutput = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnAddBase = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(12, 41);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 20);
            this.txtName.TabIndex = 0;
            // 
            // txtProtein
            // 
            this.txtProtein.Location = new System.Drawing.Point(12, 76);
            this.txtProtein.Name = "txtProtein";
            this.txtProtein.Size = new System.Drawing.Size(100, 20);
            this.txtProtein.TabIndex = 1;
            // 
            // txtCarbs
            // 
            this.txtCarbs.Location = new System.Drawing.Point(12, 111);
            this.txtCarbs.Name = "txtCarbs";
            this.txtCarbs.Size = new System.Drawing.Size(100, 20);
            this.txtCarbs.TabIndex = 2;
            // 
            // txtCalories
            // 
            this.txtCalories.Location = new System.Drawing.Point(12, 149);
            this.txtCalories.Name = "txtCalories";
            this.txtCalories.Size = new System.Drawing.Size(100, 20);
            this.txtCalories.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(119, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Название продукта";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(119, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Белки, г";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(119, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Углеводы, г";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(119, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Каллорийность, г";
            // 
            // btnAddDerived
            // 
            this.btnAddDerived.Location = new System.Drawing.Point(122, 188);
            this.btnAddDerived.Name = "btnAddDerived";
            this.btnAddDerived.Size = new System.Drawing.Size(104, 37);
            this.btnAddDerived.TabIndex = 8;
            this.btnAddDerived.Text = "Добавить ул-ый продукт\r\n";
            this.btnAddDerived.UseVisualStyleBackColor = true;
            this.btnAddDerived.Click += new System.EventHandler(this.btnAddDerived_Click);
            // 
            // btnRemoveByName
            // 
            this.btnRemoveByName.Location = new System.Drawing.Point(12, 268);
            this.btnRemoveByName.Name = "btnRemoveByName";
            this.btnRemoveByName.Size = new System.Drawing.Size(100, 37);
            this.btnRemoveByName.TabIndex = 9;
            this.btnRemoveByName.Text = "Удалить по названию";
            this.btnRemoveByName.UseVisualStyleBackColor = true;
            this.btnRemoveByName.Click += new System.EventHandler(this.btnRemoveByName_Click);
            // 
            // txtRemoveName
            // 
            this.txtRemoveName.Location = new System.Drawing.Point(12, 242);
            this.txtRemoveName.Name = "txtRemoveName";
            this.txtRemoveName.Size = new System.Drawing.Size(100, 20);
            this.txtRemoveName.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(119, 245);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(177, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Название продукта для удаления";
            // 
            // listBoxOutput
            // 
            this.listBoxOutput.FormattingEnabled = true;
            this.listBoxOutput.Location = new System.Drawing.Point(350, 41);
            this.listBoxOutput.Name = "listBoxOutput";
            this.listBoxOutput.Size = new System.Drawing.Size(568, 264);
            this.listBoxOutput.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(350, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Вывод информации";
            // 
            // btnAddBase
            // 
            this.btnAddBase.Location = new System.Drawing.Point(13, 188);
            this.btnAddBase.Name = "btnAddBase";
            this.btnAddBase.Size = new System.Drawing.Size(103, 37);
            this.btnAddBase.TabIndex = 14;
            this.btnAddBase.Text = "Добавить базовый продукт";
            this.btnAddBase.UseVisualStyleBackColor = true;
            this.btnAddBase.Click += new System.EventHandler(this.btnAddBase_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1047, 450);
            this.Controls.Add(this.btnAddBase);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.listBoxOutput);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtRemoveName);
            this.Controls.Add(this.btnRemoveByName);
            this.Controls.Add(this.btnAddDerived);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCalories);
            this.Controls.Add(this.txtCarbs);
            this.Controls.Add(this.txtProtein);
            this.Controls.Add(this.txtName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtProtein;
        private System.Windows.Forms.TextBox txtCarbs;
        private System.Windows.Forms.TextBox txtCalories;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAddDerived;
        private System.Windows.Forms.Button btnRemoveByName;
        private System.Windows.Forms.TextBox txtRemoveName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox listBoxOutput;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnAddBase;
    }
}

