﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd3_IsomatovS_pr24
{
    public class Food
    {
        public string Name { get; set; }
        public double Protein { get; set; }
        public double Carbs { get; set; }

        public Food(string name, double protein, double carbs) 
        {
            Name = name;
            Protein = protein;
            Carbs = carbs;
        }

        // Метод вычисления качества
        public virtual double CalculateQ() => Carbs * 4 + Protein * 4;

        // Информация об объекте
        public override string ToString()
        {
            return $"Продукт: {Name}, Белки:{Protein}, Углеводы:{Carbs}, Q:{CalculateQ():F2}";
        }
    }
}
