﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zd3_IsomatovS_pr24
{
    public partial class Form1 : Form
    {
        // Используем две коллекции
        private List<Food> foodList = new List<Food>();
        private Dictionary<string, Food> foodMap = new Dictionary<string, Food>();

        public Form1()
        {
            InitializeComponent();
        }
               

        private void btnAddBase_Click(object sender, EventArgs e)
        {
            var name = txtName.Text;
            if (double.TryParse(txtProtein.Text, out double protein) && double.TryParse(txtCarbs.Text, out double carbs))
            {
                var food = new Food(name, protein, carbs);
                AddFood(food);
            }
        }

        private void btnRemoveByName_Click(object sender, EventArgs e)
        {
            string name = txtRemoveName.Text;

            // Удаляем из обоих коллекций
            foodList = foodList.Where(f => f.Name != name).ToList();
            foodMap.Remove(name);

            RefreshList();
        }


        private void btnAddDerived_Click(object sender, EventArgs e)
        {
            var name = txtName.Text;
            if (double.TryParse(txtProtein.Text, out double protein) &&
                double.TryParse(txtCarbs.Text, out double carbs) &&
                double.TryParse(txtCalories.Text, out double calories))
            {
                var food = new HighCalorieFood(name, protein, carbs, calories);
                AddFood(food);
            }
        }

        // Перегрузка 1
        private void AddFood(Food food)
        {
            foodList.Add(food);
            foodMap[food.Name] = food;
            RefreshList();
        }

        // Перегрузка 2
        private void AddFood(string name, double protein, double carbs)
        {
            var food = new Food(name, protein, carbs);
            AddFood(food);
        }

        private void RefreshList()
        {
            listBoxOutput.Items.Clear();

            // LINQ: сортировка по Q
            var sorted = foodList.OrderByDescending(f => f.CalculateQ());

            foreach (var item in sorted)
                listBoxOutput.Items.Add(item.ToString());
        }
    }
}
